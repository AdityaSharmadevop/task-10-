import { createFileRoute } from "@tanstack/react-router";
import type { CSSProperties } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Aditya Sharma — Personal Portfolio" },
      {
        name: "description",
        content: "Portfolio of Aditya Sharma: about me, skills in HTML, CSS and web design, and selected projects.",
      },
      { property: "og:title", content: "Aditya Sharma — Personal Portfolio" },
      {
        property: "og:description",
        content: "About me, skills and projects by Aditya Sharma, a student web developer.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const skills = [
  { icon: "</>", name: "HTML5", level: 90, note: "Semantic, accessible, W3C-valid markup." },
  { icon: "{ }", name: "CSS3", level: 85, note: "Flexbox, Grid, transitions and hover effects." },
  { icon: "JS", name: "JavaScript", level: 65, note: "DOM interactions and small UI behaviours." },
  { icon: "⇆", name: "Responsive Design", level: 80, note: "Layouts that work on phone and desktop." },
  { icon: "✦", name: "AI-assisted Coding", level: 75, note: "Using AI tools to plan, build and debug." },
  { icon: "✓", name: "Web Standards", level: 85, note: "Validating with the W3C HTML validator." },
];

const tools = ["VS Code", "Git & GitHub", "Chrome DevTools", "Figma", "W3C Validator", "AI Assistants"];

const projects = [
  { n: "01", title: "Personal Portfolio", tag: "HTML · CSS" },
  { n: "02", title: "Landing Page Clone", tag: "Responsive layout" },
  { n: "03", title: "To-Do List App", tag: "JavaScript" },
];

function Index() {
  return (
    <div className="min-h-screen">
      {/* Nav */}
      <header className="sticky top-0 z-20 border-b border-border/60 bg-background/80 backdrop-blur">
        <nav className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <a href="#top" className="font-display text-xl font-semibold">
            Aditya<span className="text-primary">.</span>
          </a>
          <ul className="flex gap-6 text-sm font-medium sm:gap-8">
            <li><a className="nav-link" href="#about">About</a></li>
            <li><a className="nav-link" href="#skills">Skills</a></li>
            <li><a className="nav-link" href="#projects">Projects</a></li>
            <li><a className="nav-link" href="#contact">Contact</a></li>
          </ul>
        </nav>
      </header>

      <main id="top">
        {/* Hero */}
        <section className="mx-auto grid max-w-6xl items-center gap-12 px-6 pb-24 pt-16 md:grid-cols-[1.3fr_1fr] md:pt-24">
          <div className="animate-rise">
            <p className="mb-6 inline-flex items-center gap-2 rounded-full border border-border bg-card px-4 py-1.5 text-sm text-muted-foreground">
              <span className="size-2 rounded-full bg-primary" /> Open to internships
            </p>
            <h1 className="text-5xl font-medium leading-[1.05] sm:text-7xl">
              Hi, I'm Aditya — I build{" "}
              <em className="text-primary">clean, simple</em> websites.
            </h1>
            <p className="mt-6 max-w-lg text-lg text-muted-foreground">
              A student web developer who enjoys turning ideas into well-structured pages with HTML, CSS
              and a little help from AI.
            </p>
            <div className="mt-10 flex flex-wrap gap-3">
              <a href="#projects" className="btn-primary">See my work →</a>
              <a href="#contact" className="btn-ghost">Get in touch</a>
            </div>
          </div>
          <div className="animate-rise flex justify-center [animation-delay:150ms]">
            <div className="portrait grid aspect-square w-72 place-items-center bg-ink text-ink-foreground sm:w-80">
              <span className="font-display text-8xl italic">AS</span>
            </div>
          </div>
        </section>

        {/* About */}
        <section id="about" className="scroll-mt-20 bg-ink text-ink-foreground">
          <div className="mx-auto grid max-w-6xl gap-10 px-6 py-24 md:grid-cols-[1fr_2fr]">
            <h2 className="text-4xl sm:text-5xl">
              About <em className="text-primary">me</em>
            </h2>
            <div className="space-y-5 text-lg leading-relaxed opacity-90">
              <p>
                I'm Aditya Sharma, a learner from India exploring the world of web development. I like
                building pages that look good, load fast and are easy to read.
              </p>
              <p>
                While making this portfolio I learned why structured code matters — clear sections, meaningful
                tags and tidy styles — and how validating with the W3C HTML validator keeps a page correct and
                standards-compliant.
              </p>
              <dl className="grid grid-cols-3 gap-6 pt-6">
                {[
                  ["6+", "Skills"],
                  ["3", "Projects"],
                  ["100%", "Valid HTML"],
                ].map(([v, l]) => (
                  <div key={l}>
                    <dt className="font-display text-4xl text-primary">{v}</dt>
                    <dd className="text-sm opacity-70">{l}</dd>
                  </div>
                ))}
              </dl>
            </div>
          </div>
        </section>

        {/* Skills */}
        <section id="skills" className="mx-auto max-w-6xl scroll-mt-20 px-6 py-24">
          <div className="mb-12 flex flex-wrap items-end justify-between gap-4">
            <h2 className="text-4xl sm:text-5xl">
              My <em className="text-primary">skills</em>
            </h2>
            <p className="max-w-sm text-muted-foreground">Hover over a card to see it come alive.</p>
          </div>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {skills.map((s) => (
              <article key={s.name} className="skill-card">
                <div className="skill-icon font-mono text-base font-bold">{s.icon}</div>
                <h3 className="mt-5 text-2xl">{s.name}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{s.note}</p>
                <div className="mt-6 flex items-center gap-3">
                  <div className="skill-bar flex-1">
                    <span style={{ "--level": `${s.level}%` } as CSSProperties} />
                  </div>
                  <span className="text-sm font-semibold">{s.level}%</span>
                </div>
              </article>
            ))}
          </div>
          <div className="mt-12 flex flex-wrap gap-2">
            {tools.map((t) => (
              <span key={t} className="chip">{t}</span>
            ))}
          </div>
        </section>

        {/* Projects */}
        <section id="projects" className="mx-auto max-w-6xl scroll-mt-20 px-6 pb-24">
          <h2 className="mb-10 text-4xl sm:text-5xl">
            Selected <em className="text-primary">projects</em>
          </h2>
          <div className="border-b border-border">
            {projects.map((p) => (
              <a key={p.n} href="#contact" className="project-row">
                <span className="font-mono text-sm text-muted-foreground">{p.n}</span>
                <span>
                  <span className="block font-display text-2xl sm:text-3xl">{p.title}</span>
                  <span className="text-sm text-muted-foreground">{p.tag}</span>
                </span>
                <span className="project-arrow text-2xl">→</span>
              </a>
            ))}
          </div>
        </section>

        {/* Contact */}
        <section id="contact" className="scroll-mt-20 border-t border-border bg-secondary">
          <div className="mx-auto max-w-6xl px-6 py-24 text-center">
            <h2 className="text-4xl sm:text-6xl">
              Let's build something <em className="text-primary">together</em>.
            </h2>
            <p className="mx-auto mt-5 max-w-md text-muted-foreground">
              Have a project, an idea or just want to say hello? My inbox is open.
            </p>
            <a href="mailto:aditya@example.com" className="btn-primary mt-10">
              aditya@example.com
            </a>
          </div>
        </section>
      </main>

      <footer className="mx-auto flex max-w-6xl flex-wrap justify-between gap-2 px-6 py-8 text-sm text-muted-foreground">
        <span>© 2026 Aditya Sharma</span>
        <span>Built with HTML & CSS · W3C validated</span>
      </footer>
    </div>
  );
}
